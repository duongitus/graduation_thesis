ocpa.algo.conformance.precision\_and\_fitness package
=====================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.conformance.precision_and_fitness.variants

Submodules
----------

ocpa.algo.conformance.precision\_and\_fitness.evaluator module
--------------------------------------------------------------

.. automodule:: ocpa.algo.conformance.precision_and_fitness.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.conformance.precision\_and\_fitness.utils module
----------------------------------------------------------

.. automodule:: ocpa.algo.conformance.precision_and_fitness.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.conformance.precision_and_fitness
   :members:
   :undoc-members:
   :show-inheritance:
