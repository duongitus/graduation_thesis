ocpa.algo.retrieval.event\_graph.versions package
=================================================

Submodules
----------

ocpa.algo.retrieval.event\_graph.versions.classic module
--------------------------------------------------------

.. automodule:: ocpa.algo.retrieval.event_graph.versions.classic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.retrieval.event_graph.versions
   :members:
   :undoc-members:
   :show-inheritance:
