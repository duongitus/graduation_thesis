ocpa.algo.util.retrieval.event\_graph package
=============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.util.retrieval.event_graph.versions

Submodules
----------

ocpa.algo.util.retrieval.event\_graph.algorithm module
------------------------------------------------------

.. automodule:: ocpa.algo.util.retrieval.event_graph.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util.retrieval.event_graph
   :members:
   :undoc-members:
   :show-inheritance:
