ocpa.algo.retrieval.pattern\_graph package
==========================================

Submodules
----------

ocpa.algo.retrieval.pattern\_graph.algorithm module
---------------------------------------------------

.. automodule:: ocpa.algo.retrieval.pattern_graph.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.retrieval.pattern_graph
   :members:
   :undoc-members:
   :show-inheritance:
