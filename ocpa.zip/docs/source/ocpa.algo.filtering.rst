ocpa.algo.filtering package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.filtering.graph
   ocpa.algo.filtering.log

Module contents
---------------

.. automodule:: ocpa.algo.filtering
   :members:
   :undoc-members:
   :show-inheritance:
