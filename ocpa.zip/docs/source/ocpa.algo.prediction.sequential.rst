ocpa.algo.prediction.sequential package
=======================================

Module contents
---------------

.. automodule:: ocpa.algo.prediction.sequential
   :members:
   :undoc-members:
   :show-inheritance:
