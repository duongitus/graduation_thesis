ocpa.objects.log.importer.ocel package
======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.objects.log.importer.ocel.versions

Submodules
----------

ocpa.objects.log.importer.ocel.factory module
---------------------------------------------

.. automodule:: ocpa.objects.log.importer.ocel.factory
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.objects.log.importer.ocel.parameters module
------------------------------------------------

.. automodule:: ocpa.objects.log.importer.ocel.parameters
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.objects.log.importer.ocel
   :members:
   :undoc-members:
   :show-inheritance:
