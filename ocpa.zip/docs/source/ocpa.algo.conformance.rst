ocpa.algo.conformance package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.conformance.constraint_monitoring
   ocpa.algo.conformance.precision_and_fitness

Module contents
---------------

.. automodule:: ocpa.algo.conformance
   :members:
   :undoc-members:
   :show-inheritance:
