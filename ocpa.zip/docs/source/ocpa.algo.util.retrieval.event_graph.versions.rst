ocpa.algo.util.retrieval.event\_graph.versions package
======================================================

Submodules
----------

ocpa.algo.util.retrieval.event\_graph.versions.classic module
-------------------------------------------------------------

.. automodule:: ocpa.algo.util.retrieval.event_graph.versions.classic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util.retrieval.event_graph.versions
   :members:
   :undoc-members:
   :show-inheritance:
