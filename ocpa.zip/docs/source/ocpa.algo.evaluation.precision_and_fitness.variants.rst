ocpa.algo.evaluation.precision\_and\_fitness.variants package
=============================================================

Submodules
----------

ocpa.algo.evaluation.precision\_and\_fitness.variants.replay\_context module
----------------------------------------------------------------------------

.. automodule:: ocpa.algo.evaluation.precision_and_fitness.variants.replay_context
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.evaluation.precision_and_fitness.variants
   :members:
   :undoc-members:
   :show-inheritance:
