ocpa.algo.feature\_extraction.execution\_based\_features package
================================================================

Submodules
----------

ocpa.algo.feature\_extraction.execution\_based\_features.extraction\_functions module
-------------------------------------------------------------------------------------

.. automodule:: ocpa.algo.feature_extraction.execution_based_features.extraction_functions
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.feature_extraction.execution_based_features
   :members:
   :undoc-members:
   :show-inheritance:
