ocpa.algo.util.variants.versions package
========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.util.variants.versions.utils

Submodules
----------

ocpa.algo.util.variants.versions.onephase module
------------------------------------------------

.. automodule:: ocpa.algo.util.variants.versions.onephase
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.util.variants.versions.twophase module
------------------------------------------------

.. automodule:: ocpa.algo.util.variants.versions.twophase
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util.variants.versions
   :members:
   :undoc-members:
   :show-inheritance:
