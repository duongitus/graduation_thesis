ocpa.algo.retrieval.log\_behavior package
=========================================

Submodules
----------

ocpa.algo.retrieval.log\_behavior.algorithm module
--------------------------------------------------

.. automodule:: ocpa.algo.retrieval.log_behavior.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.retrieval.log_behavior
   :members:
   :undoc-members:
   :show-inheritance:
