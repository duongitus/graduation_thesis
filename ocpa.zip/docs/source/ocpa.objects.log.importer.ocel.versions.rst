ocpa.objects.log.importer.ocel.versions package
===============================================

Submodules
----------

ocpa.objects.log.importer.ocel.versions.import\_ocel\_json module
-----------------------------------------------------------------

.. automodule:: ocpa.objects.log.importer.ocel.versions.import_ocel_json
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.objects.log.importer.ocel.versions.import\_ocel\_xml module
----------------------------------------------------------------

.. automodule:: ocpa.objects.log.importer.ocel.versions.import_ocel_xml
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.objects.log.importer.ocel.versions
   :members:
   :undoc-members:
   :show-inheritance:
