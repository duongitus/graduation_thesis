ocpa.algo.prediction.tabular package
====================================

Module contents
---------------

.. automodule:: ocpa.algo.prediction.tabular
   :members:
   :undoc-members:
   :show-inheritance:
