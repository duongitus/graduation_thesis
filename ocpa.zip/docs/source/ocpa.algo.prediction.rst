ocpa.algo.prediction package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.prediction.graph
   ocpa.algo.prediction.sequential
   ocpa.algo.prediction.tabular

Module contents
---------------

.. automodule:: ocpa.algo.prediction
   :members:
   :undoc-members:
   :show-inheritance:
