ocpa.algo.evaluation package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.evaluation.precision_and_fitness

Module contents
---------------

.. automodule:: ocpa.algo.evaluation
   :members:
   :undoc-members:
   :show-inheritance:
