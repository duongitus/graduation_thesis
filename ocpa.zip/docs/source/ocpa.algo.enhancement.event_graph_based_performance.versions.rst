ocpa.algo.enhancement.event\_graph\_based\_performance.versions package
=======================================================================

Submodules
----------

ocpa.algo.enhancement.event\_graph\_based\_performance.versions.perfectly\_fitting module
-----------------------------------------------------------------------------------------

.. automodule:: ocpa.algo.enhancement.event_graph_based_performance.versions.perfectly_fitting
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.enhancement.event_graph_based_performance.versions
   :members:
   :undoc-members:
   :show-inheritance:
