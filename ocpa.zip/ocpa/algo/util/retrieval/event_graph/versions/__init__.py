from ocpa.algo.util.retrieval.event_graph.versions import classic
