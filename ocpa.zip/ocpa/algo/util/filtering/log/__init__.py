import ocpa.algo.util.filtering.log.activity_filtering
import ocpa.algo.util.filtering.log.case_filtering
import ocpa.algo.util.filtering.log.time_filtering
import ocpa.algo.util.filtering.log.variant_filtering