import ocpa.objects.oc_petri_net.obj
import ocpa.objects.oc_petri_net.properties
import ocpa.objects.oc_petri_net.semantics
